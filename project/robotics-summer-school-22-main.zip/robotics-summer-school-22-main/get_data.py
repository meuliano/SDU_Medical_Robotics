import rtde_control
import rtde_receive
import time
import numpy as np
import sys
from rtde_receive import RTDEReceiveInterface as RTDEReceive


ip = "192.168.1.105"
rtde_c = rtde_control.RTDEControlInterface(ip)
rtde_r = rtde_receive.RTDEReceiveInterface(ip)

rtde_c.teachMode()

freq = 125.0
output = "robot_data_new.csv"
dt = 1 / freq
rtde_r = RTDEReceive(ip, freq)
rtde_r.startFileRecording(output)
print("Data recording started, press [Ctrl-C] to end recording.")
i = 0
try:
    while True:
        start = time.time()
        if i % 10 == 0:
            sys.stdout.write("\r")
            sys.stdout.write("{:3d} samples.".format(i))
            sys.stdout.flush()
        end = time.time()
        duration = end - start

        if duration < dt:
            time.sleep(dt - duration)
        i += 1

except KeyboardInterrupt:
    rtde_r.stopFileRecording()
    rtde_c.endTeachMode()

    print("\nData recording stopped.")




#rtde_c.moveL(end_p.tolist())