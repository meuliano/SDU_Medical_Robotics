from __future__ import division, print_function
from dmp_position import PositionDMP
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def calculate_trajectory(start, end, output_file, tau_scale):
    # Load a demonstration file containing robot positions.
    demo = np.loadtxt("robot_data.csv", delimiter=",", skiprows=0)

    tau = 0.002 * len(demo)
    print(tau)
    t = np.arange(0, tau, 0.002)
    orientation = demo[0, 58:61]
    demo_p = demo[:, 55:58]

    # TODO: In both canonical_system.py and dmp_position.py you will find some lines missing implementation.
    # Fix those first.

    N = 50  # TODO: Try changing the number of basis functions to see how it affects the output.
    dmp = PositionDMP(n_bfs=N, alpha=48.0/10.0) # 30 for 5
    dmp.train(demo_p, t, tau)

    # TODO: Try setting a different starting point for the dmp:
    # dmp.p0 = [x, y, z]
    # dmp.p0 = [1,1,1]
    dmp.p0 = start

    # TODO: ...or a different goal point:
    # dmp.g0 = [x, y, z]
    # dmp.g0 = [1,1,1]

    # dmp.gp = [-0.077245,-0.245880,0.433351]

    dmp.gp = end

    # TODO: ...or a different time constant:
    # tau = T
    tau = tau_scale * tau


    # Generate an output trajectory from the trained DMP
    dmp_p, dmp_dp, dmp_ddp = dmp.rollout(t, tau)



    p_out = np.vstack((dmp_p.T, orientation[0]*np.ones(np.shape(dmp_p)[0]))).T
    p_out = np.vstack((p_out.T, orientation[1]*np.ones(np.shape(dmp_p)[0]))).T
    p_out = np.vstack((p_out.T, orientation[2]*np.ones(np.shape(dmp_p)[0]))).T

    
    np.savetxt(output_file, p_out, delimiter=",", fmt="%f")

    return dmp_p[-1, :]
