import rtde_control
import rtde_receive
import time
import numpy as np


ip = "192.168.1.105"
rtde_c = rtde_control.RTDEControlInterface(ip)
rtde_r = rtde_receive.RTDEReceiveInterface(ip)

init_p = np.array(rtde_r.getActualTCPPose())
print(init_p)

end_p = init_p
end_p[2] -= 0.05

#rtde_c.moveL(end_p.tolist())