from dmp import calculate_trajectory
import numpy as np
from matplotlib import pyplot as plt

csv_file = "dmp_output.csv"

# number of points x
num_x = 5
dist_x = 5. * (1/1000.) # measured in mm
# number of points y
num_y = 3
dist_y = 5. * (1/1000.) # measured in mm

# future work: z direction 

my_data = np.genfromtxt(csv_file, delimiter=',')
x_array = np.array([1,0,0]) # create empty array to move in x direction
y_array= np.array([0,1,0])  # create empty array to move in y direction

# set first end and start point of the grid
start = my_data[0, 0:3]
end = start + y_array * dist_y

# safe all points in an array for debugging
start_arr = [start]
end_arr = [end]


for i in range(0, num_x):
    _start = start
    for j in range(0, num_y):
        output_file = "robot_data_" + str(i) + str(j) + ".csv"
        dmp_p = calculate_trajectory(start, end, output_file, 1.0)
        start = dmp_p
        # use last point of the DMP to create new trajectory 
        end = start + y_array * dist_y 
        start_arr.append(start)
        end_arr.append(end)
    # move in x direction 
    start = _start + x_array * dist_x
    end = start + y_array * dist_y 
    start_arr.append(start)
    end_arr.append(end)



print(start_arr)
print(end_arr)


np.savetxt("grid_points.csv", start_arr, delimiter=",", fmt="%f")

plt.grid()
for x in range(0, len(start_arr)-1):
    plt.plot(start_arr[x][0], start_arr[x][1], marker="o", markersize=20, markeredgecolor="red", markerfacecolor="green")

plt.show()


