import rtde_control
import numpy as np

ip = "192.168.1.105"
rtde_c = rtde_control.RTDEControlInterface(ip)
freq = 125.0
csv_file = "robot_data_00.csv"

my_data = np.genfromtxt(csv_file, delimiter=',')

start_p = my_data[0, :]
dt = 1.0/freq  

print(start_p)

rtde_c.moveL(start_p)


rtde_c.servoStop()
rtde_c.stopScript()
