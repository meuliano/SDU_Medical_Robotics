import numpy as np
import matplotlib.pyplot as plt


my_data0 = np.genfromtxt("robot_data.csv", delimiter=',')


tau = 0.002 * (len(my_data0))
print(tau)
t = np.arange(0, tau, 0.002)


# 2D plot the DMP against the original demonstration
fig1, axs = plt.subplots(3, 1, sharex=True)
axs[0].set_xlabel('t (s)')
axs[0].set_ylabel('X (m)')
axs[1].set_xlabel('t (s)')
axs[1].set_ylabel('Y (m)')
axs[2].set_xlabel('t (s)')
axs[2].set_ylabel('Z (m)')

axs[0].plot(t, my_data0[:, 55], label='Demonstration')
axs[1].plot(t, my_data0[:, 56], label='Demonstration')
axs[2].plot(t, my_data0[:, 57], label='Demonstration')

for i in range(0, 3):
    for j in range(0, 5):
        file_name = "robot_data_"+str(j)+str(i)+".csv"
        label_name = "DMP"+str(j)+str(i)
        data = np.genfromtxt(file_name, delimiter=',')
        axs[0].plot(t, data[:, 0], label=label_name)
        axs[1].plot(t, data[:, 1], label=label_name)
        axs[2].plot(t, data[:, 2], label=label_name)


axs[2].legend()

# 3D plot the DMP against the original demonstration
fig2 = plt.figure(2)
ax = plt.axes(projection='3d')
ax.plot3D(my_data0[:, 55], my_data0[:, 56], my_data0[:, 57], label='Demonstration')

# ax.plot3D(my_data1[:, 0], my_data1[:, 1], my_data1[:, 2], label='Path 2')
#ax.plot3D(my_data0[:, 0], my_data0[:, 1], my_data0[:, 2], label='demo')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.legend()
plt.show()

# 3D plot the DMP against the original demonstration
# fig3 = plt.figure(3)
# ax3 = plt.axes(projection='3d')
# ax3.plot3D(my_data0[:, 0], my_data0[:, 1], my_data0[:, 2], label='demo')
# ax3.set_xlabel('X')
# ax3.set_ylabel('Y')
# ax3.set_zlabel('Z')
# ax3.legend()
# plt.show()